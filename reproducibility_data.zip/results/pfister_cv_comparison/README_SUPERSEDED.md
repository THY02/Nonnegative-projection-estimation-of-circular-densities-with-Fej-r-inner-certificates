# 作废记录：状态汇总字段覆盖

首次运行的最终样本结果在建立字典时用 `**info` 覆盖 `status='ok'`，故其摘要将已成功的 `optimal_tolerance`、`target_feasible`、`analytic` 误计成失败，`manifest.json` 中 `successful=0` 与 `failures=0` 不一致，不能使用该目录的 summary 或成功率。首次版本代码已保存为 `code/pfister_cv_comparison_v1.py`，哈希与本目录 manifest 的 source_sha256 一致。修正后的代码区分 `status` 与 `solver_status` 并在 `results/pfister_cv_comparison_v2/` 完整重跑，不覆盖此目录。两轮使用同样样本，不是独立复现。
