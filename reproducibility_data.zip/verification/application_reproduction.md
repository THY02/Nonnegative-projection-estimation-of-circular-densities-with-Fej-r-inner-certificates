# Independent application reproduction

The binned certificate and SDP application programs were rerun in a separate copy using the retained processed hourly data and original application-pilot baseline. Both completed all 12 monthly windows and returned 350 test days.

The rerun used Windows, Python 3.12.10, NumPy 2.5.4, SciPy 1.18.1, pandas 3.0.3, CVXPY 1.9.3, SCS 3.3.1 and Clarabel 0.11.1. The original lock records pandas 3.1.0, so this is not an identical environment.

Compared with saved outputs, the largest numerical differences across each CSV file were:

| Output | Certificate application | SDP baseline |
| --- | ---: | ---: |
| Summary | 1.01e-16 | 1.38e-12 |
| Daily scores | 1.34e-15 | 6.51e-10 |
| Forecast profiles | 1.12e-16 | 3.48e-11 |
| Tuning records | 5.28e-16 | 4.03e-09 |

All selected SDP forecast degrees were unchanged. One original tuning solve labelled `optimal_inaccurate` was labelled `optimal` in the rerun; all other corresponding statuses matched. Summary methods inherited from the original pilot are reused by the certificate script, so this is not an independent rerun of those pilot baselines. Differences are floating-point comparisons, not formal proofs; the reported runtime is not validated by this check.
